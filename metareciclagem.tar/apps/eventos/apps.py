

from django.apps import AppConfig


class EventosConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.eventos'
    verbose_name = 'Eventos e Cursos'

    