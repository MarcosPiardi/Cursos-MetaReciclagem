/*
Arquivo: collapsible_filter.js
Caminho: static/js/admin/collapsible_filter.js
Finalidade: Toggle do filtro lateral ao clicar no cabecalho h2
Atualizacoes:
 - 29/07/2026 - Criacao inicial
 */

(function () {
    "use strict";
    document.addEventListener("DOMContentLoaded", function () {
        var filter = document.getElementById("changelist-filter");
        if (!filter) return;

        var header = filter.querySelector("h2");
        if (!header) return;

        // Restaura estado salvo entre sessoes
        if (localStorage.getItem("admin_filter_collapsed") === "true") {
            filter.classList.add("filter-collapsed");
        }

        header.addEventListener("click", function () {
            var collapsed = filter.classList.toggle("filter-collapsed");
            localStorage.setItem("admin_filter_collapsed", collapsed);
        });
    });
})();
